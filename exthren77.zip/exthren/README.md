# Exthren
1. `npm install` 2. `OWNER_KEY=yoursecret node server.js` 3. open http://localhost:3000
Make yourself first admin: register, then run admin_whitelister.py (edit SERVER/KEY at top).
Launcher: register exthren:// URL protocol -> call POST /api/validate-join {token} to get the user.

## Put it on your domain
1. Rent a VPS (Ubuntu), install Node 18+, upload this folder, `npm install`.
2. `OWNER_KEY=yoursecret PORT=3000 pm2 start server.js --name exthren` (npm i -g pm2).
3. DNS: add an A record for yourdomain.com (and www) pointing to the VPS IP.
4. Install Caddy, put the included Caddyfile in /etc/caddy/Caddyfile with your domain, `systemctl reload caddy`. HTTPS is automatic.
5. Set SERVER in admin_whitelister.py (and your launcher) to https://yourdomain.com.
Starting Robux: 100 (change with START_ROBUX=250 env var). All Robux changes are logged in the robux_log table.

Hosting: set DB_PATH to a file on a persistent disk/volume (e.g. /data/exthren.db) so accounts survive restarts. PORT is read from the environment.

## Promo codes
Admin > Promo Codes. Each code can give Robux, an item (use the item ID shown in the Catalog or Items table), or both. Set uses to -1 for unlimited, or a number to limit how many people can redeem it. Disable or delete codes any time. Each account can redeem a code once.

## Avatars
The default body is an original blocky 3D character, rendered with three.js (loaded from cdnjs, so the browser needs internet access). Drag it to turn it. Items are layered over it by type: hat, face, shirt, t-shirt, pants and gear. Wearing a shirt removes any other shirt, and the same goes for each other type except hats and gear, which stack.

## Testing before you go live
Stop the server, delete exthren.db, start it again, sign up, then whitelist your account.
