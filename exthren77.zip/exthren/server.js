const express = require('express'), bcrypt = require('bcryptjs'), cookieParser = require('cookie-parser'), crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const START_ROBUX = Math.max(0, Math.trunc(+(process.env.START_ROBUX || 100)));
const OWNER_KEY = process.env.OWNER_KEY || 'change-me-owner-key';
const TIERS = { free: 0, classic: 15, turbo: 35, outrageous: 60 };
const SLOTS = ['hat', 'face', 'shirt', 'tshirt', 'pants', 'gear'];
const MULTI = ['hat', 'gear'];               // these types can be worn several at once
const BADGES = ['staff', 'verified'];
const BAD = ['fuck', 'shit', 'nigg', 'fag', 'bitch', 'cunt', 'rape', 'nazi', 'hitler', 'porn', 'dick'];

// ---------- database (built-in node:sqlite) ----------
const raw = new DatabaseSync(process.env.DB_PATH || 'exthren.db');
raw.exec('PRAGMA journal_mode=WAL');
const nz = a => (a === undefined || (typeof a === 'number' && !Number.isFinite(a))) ? null : a;
const stmts = new Map();
const q = sql => {
  if (!stmts.has(sql)) stmts.set(sql, raw.prepare(sql));
  const st = stmts.get(sql);
  return { run: (...a) => st.run(...a.map(nz)), get: (...a) => st.get(...a.map(nz)), all: (...a) => st.all(...a.map(nz)) };
};
const tx = fn => (...a) => { raw.exec('BEGIN'); try { const r = fn(...a); raw.exec('COMMIT'); return r; } catch (e) { raw.exec('ROLLBACK'); throw e; } };

raw.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT UNIQUE COLLATE NOCASE,hash TEXT,robux INTEGER DEFAULT 0,admin INTEGER DEFAULT 0,banned INTEGER DEFAULT 0,created INTEGER,last_seen INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,uid INTEGER,created INTEGER);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,name TEXT,price INTEGER DEFAULT 0,type TEXT DEFAULT 'hat',img TEXT,stock INTEGER DEFAULT -1,roblox_id TEXT,live_at INTEGER DEFAULT 0,hidden INTEGER DEFAULT 0,created INTEGER);
CREATE TABLE IF NOT EXISTS inv(uid INTEGER,item INTEGER,worn INTEGER DEFAULT 0,PRIMARY KEY(uid,item));
CREATE TABLE IF NOT EXISTS badges(uid INTEGER,badge TEXT,PRIMARY KEY(uid,badge));
CREATE TABLE IF NOT EXISTS promos(code TEXT PRIMARY KEY,robux INTEGER DEFAULT 0,item_id INTEGER,uses INTEGER DEFAULT -1,active INTEGER DEFAULT 1,created INTEGER);
CREATE TABLE IF NOT EXISTS redeemed(uid INTEGER,code TEXT,PRIMARY KEY(uid,code));
CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY,frm INTEGER,too INTEGER,give INTEGER,want INTEGER,status TEXT DEFAULT 'pending',ts INTEGER);
CREATE TABLE IF NOT EXISTS joins(token TEXT PRIMARY KEY,uid INTEGER,game INTEGER,exp INTEGER);
CREATE TABLE IF NOT EXISTS plays(game INTEGER,uid INTEGER,ts INTEGER);
CREATE TABLE IF NOT EXISTS feed(id INTEGER PRIMARY KEY,uid INTEGER,body TEXT,ts INTEGER);
CREATE TABLE IF NOT EXISTS blog(id INTEGER PRIMARY KEY,title TEXT,author TEXT,views INTEGER DEFAULT 0,ts INTEGER);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,title TEXT,img TEXT);
CREATE TABLE IF NOT EXISTS games(id INTEGER PRIMARY KEY,name TEXT,img TEXT,creator TEXT,updated INTEGER);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY,frm INTEGER,too INTEGER,body TEXT,read INTEGER DEFAULT 0,ts INTEGER);
CREATE TABLE IF NOT EXISTS bc(uid INTEGER PRIMARY KEY,tier TEXT DEFAULT 'free',claimed INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS robux_log(id INTEGER PRIMARY KEY,uid INTEGER,amount INTEGER,reason TEXT,ts INTEGER);`);
// upgrade older databases (ignored if the column already exists)
const alter = (t, c, d) => { try { raw.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${d}`); } catch {} };
alter('users', 'last_seen', 'INTEGER DEFAULT 0'); alter('items', 'hidden', 'INTEGER DEFAULT 0'); alter('items', 'created', 'INTEGER');
alter('promos', 'item_id', 'INTEGER'); alter('promos', 'active', 'INTEGER DEFAULT 1'); alter('promos', 'created', 'INTEGER');
alter('games', 'creator', 'TEXT'); alter('games', 'updated', 'INTEGER'); alter('trades', 'ts', 'INTEGER');
if (!q('SELECT 1 FROM games').get()) q('INSERT INTO games(name,img,creator,updated) VALUES(?,?,?,?)').run('Exthren Baseplate', '', 'Exthren', Date.now());
if (!q('SELECT 1 FROM blog').get()) q('INSERT INTO blog(title,author,ts) VALUES(?,?,?)').run('Welcome to Exthren!', 'Exthren', Date.now());

// ---------- helpers ----------
const clean = t => { const l = String(t).toLowerCase(); return !BAD.some(b => l.includes(b)); };
const byName = n => q('SELECT * FROM users WHERE name=?').get(String(n || '').trim());
const log = (uid, amt, why) => q('INSERT INTO robux_log(uid,amount,reason,ts) VALUES(?,?,?,?)').run(uid, amt, why, Date.now());
const badgesOf = id => q('SELECT badge FROM badges WHERE uid=?').all(id).map(b => b.badge);
const wornOf = id => q('SELECT i.id,i.name,i.img,i.type FROM inv v JOIN items i ON i.id=v.item WHERE v.uid=? AND v.worn=1').all(id);
const checkName = n => {
  if (!/^[A-Za-z0-9_]{3,20}$/.test(n || '')) return 'Names are 3-20 letters, numbers or underscores';
  const l = n.toLowerCase().replace(/0/g, 'o').replace(/1/g, 'i').replace(/3/g, 'e').replace(/4/g, 'a').replace(/5/g, 's');
  if (!clean(l) || l.includes('admin') || l.includes('exthren') || l.includes('roblox')) return 'That name is not allowed';
  if (byName(n)) return 'That name is already taken';
  return null;
};
const sign = (res, uid) => {
  const t = crypto.randomBytes(24).toString('hex');
  q('INSERT INTO sessions(token,uid,created) VALUES(?,?,?)').run(t, uid, Date.now());
  res.cookie('s', t, { httpOnly: true, sameSite: 'lax', maxAge: 2592e6 });
};
const keyOk = k => { const a = Buffer.from(String(k || '')), b = Buffer.from(OWNER_KEY); return a.length === b.length && crypto.timingSafeEqual(a, b); };

// ---------- app ----------
const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }), cookieParser(), express.static('public'));

const auth = (req, res, next) => {
  const t = req.cookies && req.cookies.s;
  if (!t) return res.status(401).json({ error: 'Not logged in' });
  const u = q('SELECT u.* FROM sessions s JOIN users u ON u.id=s.uid WHERE s.token=?').get(t);
  if (!u) return res.status(401).json({ error: 'Your session ended. Please log in again.' });
  if (u.banned) return res.status(403).json({ error: 'This account is banned' });
  if (Date.now() - (u.last_seen || 0) > 6e4) q('UPDATE users SET last_seen=? WHERE id=?').run(Date.now(), u.id);
  req.u = u; next();
};
const adm = (req, res, next) => req.u.admin ? next() : res.status(403).json({ error: 'Admins only' });
const A = [auth, adm];

// accounts
app.get('/api/checkname', (req, res) => res.json({ error: checkName(String(req.query.n || '')) }));
app.post('/api/register', (req, res) => {
  const name = String(req.body.name || '').trim(), pw = String(req.body.password || '');
  const e = checkName(name); if (e) return res.status(400).json({ error: e });
  if (pw.length < 6 || pw.length > 100) return res.status(400).json({ error: 'Password must be 6 to 100 characters' });
  const now = Date.now();
  const id = Number(q('INSERT INTO users(name,hash,robux,created,last_seen) VALUES(?,?,?,?,?)').run(name, bcrypt.hashSync(pw, 10), START_ROBUX, now, now).lastInsertRowid);
  log(id, START_ROBUX, 'signup bonus');
  sign(res, id); res.json({ ok: 1 });
});
app.post('/api/login', (req, res) => {
  const u = byName(req.body.name);
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.hash)) return res.status(400).json({ error: 'Wrong username or password' });
  if (u.banned) return res.status(403).json({ error: 'This account is banned' });
  sign(res, u.id); res.json({ ok: 1 });
});
app.post('/api/logout', (req, res) => {
  if (req.cookies && req.cookies.s) q('DELETE FROM sessions WHERE token=?').run(req.cookies.s);
  res.clearCookie('s'); res.json({ ok: 1 });
});
app.get('/api/me', auth, (req, res) => {
  const { id, name, robux, admin } = req.u;
  res.json({ id, name, robux, admin, badges: badgesOf(id), worn: wornOf(id) });
});
app.get('/api/user/:name', (req, res) => {
  const u = q('SELECT id,name,created FROM users WHERE name=? AND banned=0').get(req.params.name);
  if (!u) return res.status(404).json({ error: 'User not found' });
  res.json({ ...u, badges: badgesOf(u.id), worn: wornOf(u.id) });
});
app.get('/api/notifs', auth, (req, res) => res.json({
  msgs: q('SELECT COUNT(*) c FROM msgs WHERE too=? AND read=0').get(req.u.id).c,
  trades: q("SELECT COUNT(*) c FROM trades WHERE too=? AND status='pending'").get(req.u.id).c,
}));

// catalog, buying, avatar
app.get('/api/catalog', (req, res) => res.json(q('SELECT * FROM items WHERE live_at<=? AND hidden=0 ORDER BY id DESC').all(Date.now())));
const buyItem = tx((uid, id) => {
  const it = q('SELECT * FROM items WHERE id=? AND live_at<=? AND hidden=0').get(id, Date.now());
  if (!it) throw new Error('That item is not available');
  if (q('SELECT 1 FROM inv WHERE uid=? AND item=?').get(uid, it.id)) throw new Error('You already own this');
  if (it.stock === 0) throw new Error('Sold out');
  const me = q('SELECT robux FROM users WHERE id=?').get(uid);
  if (me.robux < it.price) throw new Error('Not enough Robux');
  q('UPDATE users SET robux=robux-? WHERE id=?').run(it.price, uid);
  if (it.stock > 0) q('UPDATE items SET stock=stock-1 WHERE id=?').run(it.id);
  q('INSERT INTO inv(uid,item,worn) VALUES(?,?,0)').run(uid, it.id);
  log(uid, -it.price, 'bought ' + it.name);
  return it;
});
app.post('/api/buy/:id', auth, (req, res) => {
  try { buyItem(req.u.id, Number(req.params.id)); res.json({ ok: 1 }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/inventory', auth, (req, res) =>
  res.json(q('SELECT i.*,v.worn FROM inv v JOIN items i ON i.id=v.item WHERE v.uid=? ORDER BY i.type,i.name').all(req.u.id)));
app.post('/api/wear/:id', auth, (req, res) => {
  const id = Number(req.params.id);
  const own = q('SELECT v.worn,i.type FROM inv v JOIN items i ON i.id=v.item WHERE v.uid=? AND v.item=?').get(req.u.id, id);
  if (!own) return res.status(404).json({ error: 'You do not own that item' });
  if (own.worn) { q('UPDATE inv SET worn=0 WHERE uid=? AND item=?').run(req.u.id, id); return res.json({ ok: 1, worn: 0 }); }
  if (!MULTI.includes(own.type))   // one shirt, one pair of pants, etc. at a time
    q('UPDATE inv SET worn=0 WHERE uid=? AND item IN (SELECT id FROM items WHERE type=?)').run(req.u.id, own.type);
  q('UPDATE inv SET worn=1 WHERE uid=? AND item=?').run(req.u.id, id);
  res.json({ ok: 1, worn: 1 });
});
app.post('/api/unwear', auth, (req, res) => { q('UPDATE inv SET worn=0 WHERE uid=?').run(req.u.id); res.json({ ok: 1 }); });

// promo codes (can give Robux, an item, or both)
const redeemCode = tx((uid, input) => {
  const code = String(input || '').trim().toUpperCase();
  if (!code) throw new Error('Enter a code');
  const p = q('SELECT * FROM promos WHERE code=?').get(code);
  if (!p || !p.active) throw new Error('Invalid or disabled code');
  if (p.uses === 0) throw new Error('This code has been used up');
  if (q('SELECT 1 FROM redeemed WHERE uid=? AND code=?').get(uid, code)) throw new Error('You already redeemed this code');
  const got = [];
  if (p.item_id) {
    const it = q('SELECT * FROM items WHERE id=?').get(p.item_id);
    if (it && !q('SELECT 1 FROM inv WHERE uid=? AND item=?').get(uid, it.id)) {
      q('INSERT INTO inv(uid,item,worn) VALUES(?,?,0)').run(uid, it.id); got.push(it.name);
    } else if (it) got.push(it.name + ' (you already own it)');
  }
  if (p.robux > 0) { q('UPDATE users SET robux=robux+? WHERE id=?').run(p.robux, uid); log(uid, p.robux, 'promo ' + code); got.push('R$ ' + p.robux); }
  if (p.uses > 0) q('UPDATE promos SET uses=uses-1 WHERE code=?').run(code);
  q('INSERT INTO redeemed(uid,code) VALUES(?,?)').run(uid, code);
  return got;
});
app.post('/api/redeem', auth, (req, res) => {
  try { res.json({ ok: 1, got: redeemCode(req.u.id, req.body.code) }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

// trading (item for item)
const swap = tx(t => {
  const has = (uid, item) => q('SELECT 1 FROM inv WHERE uid=? AND item=?').get(uid, item);
  if (!has(t.frm, t.give) || !has(t.too, t.want)) throw new Error('One of the items is no longer owned');
  if (has(t.too, t.give) || has(t.frm, t.want)) throw new Error('One of you already owns the item you would receive');
  q('DELETE FROM inv WHERE uid=? AND item=?').run(t.frm, t.give);
  q('DELETE FROM inv WHERE uid=? AND item=?').run(t.too, t.want);
  q('INSERT INTO inv(uid,item,worn) VALUES(?,?,0)').run(t.too, t.give);
  q('INSERT INTO inv(uid,item,worn) VALUES(?,?,0)').run(t.frm, t.want);
  q("UPDATE trades SET status='done' WHERE id=?").run(t.id);
});
app.post('/api/trade', auth, (req, res) => {
  const t = byName(req.body.to);
  const give = Number(req.body.give), want = Number(req.body.want);
  if (!t || t.id === req.u.id) return res.status(400).json({ error: 'Pick a valid user to trade with' });
  if (!q('SELECT 1 FROM inv WHERE uid=? AND item=?').get(req.u.id, give)) return res.status(400).json({ error: 'You do not own the item you are offering' });
  if (!q('SELECT 1 FROM inv WHERE uid=? AND item=?').get(t.id, want)) return res.status(400).json({ error: 'They do not own that item' });
  q('INSERT INTO trades(frm,too,give,want,ts) VALUES(?,?,?,?,?)').run(req.u.id, t.id, give, want, Date.now());
  res.json({ ok: 1 });
});
app.get('/api/trades', auth, (req, res) => res.json(q(`SELECT t.*,f.name fname,o.name tname,g.name gname,w.name wname
  FROM trades t JOIN users f ON f.id=t.frm JOIN users o ON o.id=t.too JOIN items g ON g.id=t.give JOIN items w ON w.id=t.want
  WHERE (t.frm=? OR t.too=?) AND t.status='pending' ORDER BY t.id DESC`).all(req.u.id, req.u.id)));
app.post('/api/trade/:id/:act', auth, (req, res) => {
  const id = Number(req.params.id);
  const t = q("SELECT * FROM trades WHERE id=? AND status='pending'").get(id);
  if (!t || (t.frm !== req.u.id && t.too !== req.u.id)) return res.status(404).json({ error: 'Trade not found' });
  if (req.params.act !== 'accept' || t.too !== req.u.id) {
    q("UPDATE trades SET status='declined' WHERE id=?").run(id); return res.json({ ok: 1 });
  }
  try { swap(t); res.json({ ok: 1 }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

// games, joining, people
app.get('/api/games', (req, res) => res.json(q(`SELECT g.id,g.name,g.img,COALESCE(g.creator,'Exthren') creator,COALESCE(g.updated,0) updated,
  (SELECT COUNT(*) FROM plays WHERE game=g.id) played,
  (SELECT COUNT(DISTINCT uid) FROM plays WHERE game=g.id AND ts>?) players FROM games g`).all(Date.now() - 3e5)));
app.post('/api/play/:game', auth, (req, res) => {
  const g = q('SELECT id FROM games WHERE id=?').get(Number(req.params.game));
  if (!g) return res.status(404).json({ error: 'Game not found' });
  const t = crypto.randomBytes(16).toString('hex');
  q('INSERT INTO joins(token,uid,game,exp) VALUES(?,?,?,?)').run(t, req.u.id, g.id, Date.now() + 6e4);
  res.json({ url: `exthren://join?token=${t}&game=${g.id}`, token: t });
});
// the game launcher calls this with the token from exthren://join
app.post('/api/validate-join', (req, res) => {
  const tok = String(req.body.token || '');
  const j = q('SELECT * FROM joins WHERE token=? AND exp>?').get(tok, Date.now());
  if (!j) return res.status(400).json({ error: 'Join token expired or invalid' });
  q('DELETE FROM joins WHERE token=?').run(tok);
  q('INSERT INTO plays(game,uid,ts) VALUES(?,?,?)').run(j.game, j.uid, Date.now());
  res.json({ user: q('SELECT id,name FROM users WHERE id=?').get(j.uid), game: j.game });
});
app.get('/api/people', (req, res) => {
  const s = String(req.query.q || '').replace(/[%_]/g, '').slice(0, 20);
  res.json(q(`SELECT u.name,u.last_seen,(SELECT body FROM feed WHERE uid=u.id ORDER BY id DESC LIMIT 1) blurb,
    (SELECT g.name FROM plays p JOIN games g ON g.id=p.game WHERE p.uid=u.id AND p.ts>? ORDER BY p.ts DESC LIMIT 1) place
    FROM users u WHERE u.banned=0 AND u.name LIKE ? ORDER BY u.last_seen DESC LIMIT 30`).all(Date.now() - 3e5, '%' + s + '%'));
});
app.get('/api/events', (req, res) => res.json(q('SELECT * FROM events ORDER BY id DESC LIMIT 5').all()));
app.get('/api/blog', (req, res) => res.json(q('SELECT * FROM blog ORDER BY id DESC LIMIT 10').all()));
app.post('/api/blog/:id/view', (req, res) => { q('UPDATE blog SET views=views+1 WHERE id=?').run(Number(req.params.id)); res.json({ ok: 1 }); });

// feed and messages
app.get('/api/feed', (req, res) => {
  const u = String(req.query.user || '').trim();
  const rows = u
    ? q('SELECT f.id,f.body,f.ts,u.name FROM feed f JOIN users u ON u.id=f.uid WHERE u.name=? ORDER BY f.id DESC LIMIT 30').all(u)
    : q('SELECT f.id,f.body,f.ts,u.name FROM feed f JOIN users u ON u.id=f.uid ORDER BY f.id DESC LIMIT 30').all();
  res.json(rows);
});
app.post('/api/feed', auth, (req, res) => {
  const b = String(req.body.body || '').trim().slice(0, 200);
  if (!b) return res.status(400).json({ error: 'Write something first' });
  if (!clean(b)) return res.status(400).json({ error: 'That contains words that are not allowed' });
  q('INSERT INTO feed(uid,body,ts) VALUES(?,?,?)').run(req.u.id, b, Date.now());
  res.json({ ok: 1 });
});
app.get('/api/msgs', auth, (req, res) => {
  const m = q('SELECT m.id,m.body,m.ts,u.name FROM msgs m JOIN users u ON u.id=m.frm WHERE m.too=? ORDER BY m.id DESC LIMIT 50').all(req.u.id);
  q('UPDATE msgs SET read=1 WHERE too=?').run(req.u.id);
  res.json(m);
});
app.post('/api/msg', auth, (req, res) => {
  const t = byName(req.body.to);
  const b = String(req.body.body || '').trim().slice(0, 500);
  if (!t) return res.status(404).json({ error: 'No such user' });
  if (!b) return res.status(400).json({ error: 'Write a message first' });
  if (!clean(b)) return res.status(400).json({ error: 'That contains words that are not allowed' });
  q('INSERT INTO msgs(frm,too,body,ts) VALUES(?,?,?,?)').run(req.u.id, t.id, b, Date.now());
  res.json({ ok: 1 });
});

// Builders Club
const bcRow = id => q('SELECT * FROM bc WHERE uid=?').get(id) || { tier: 'free', claimed: 0 };
app.get('/api/bcinfo', auth, (req, res) => { const b = bcRow(req.u.id); res.json({ tier: b.tier, claimed: b.claimed, perDay: TIERS[b.tier] || 0 }); });
app.post('/api/bc/claim', auth, (req, res) => {
  const b = bcRow(req.u.id), amt = TIERS[b.tier] || 0;
  if (!amt) return res.status(400).json({ error: 'Join a Builders Club tier first' });
  const left = (b.claimed || 0) + 864e5 - Date.now();
  if (left > 0) return res.status(400).json({ error: `You can claim again in ${Math.ceil(left / 36e5)} hour(s)` });
  q('INSERT INTO bc(uid,tier,claimed) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET claimed=excluded.claimed').run(req.u.id, b.tier, Date.now());
  q('UPDATE users SET robux=robux+? WHERE id=?').run(amt, req.u.id);
  log(req.u.id, amt, 'daily ' + b.tier);
  res.json({ ok: 1, robux: amt });
});
app.post('/api/bc/:tier', auth, (req, res) => {
  const t = req.params.tier;
  if (!Object.hasOwn(TIERS, t)) return res.status(400).json({ error: 'Unknown tier' });
  q('INSERT INTO bc(uid,tier,claimed) VALUES(?,?,0) ON CONFLICT(uid) DO UPDATE SET tier=excluded.tier').run(req.u.id, t);
  res.json({ ok: 1 });
});
app.get('/api/config', (req, res) => res.json({ buyUrl: process.env.BUY_URL || '' }));

// admin panel
app.get('/api/admin/items', A, (req, res) => res.json(q('SELECT * FROM items ORDER BY id DESC LIMIT 200').all()));
app.post('/api/admin/item', A, async (req, res) => {
  let name = String(req.body.name || '').trim().slice(0, 60);
  let price = req.body.price, img = String(req.body.img || '').trim(), stock = req.body.stock;
  const rid = String(req.body.roblox_id || '').trim().replace(/\D/g, '');
  if (rid && !name) {   // look up an asset ID to fill in name, price and picture
    try {
      const d = await (await fetch('https://economy.roblox.com/v2/assets/' + rid + '/details', { signal: AbortSignal.timeout(8000) })).json();
      name = String(d.Name || '').slice(0, 60);
      if (price === '' || price == null) price = d.PriceInRobux;
    } catch {}
    img = img || `https://www.roblox.com/asset-thumbnail/image?assetId=${rid}&width=150&height=150&format=png`;
  }
  if (!name) return res.status(400).json({ error: 'Enter a name, or a valid asset ID' });
  const type = SLOTS.includes(req.body.type) ? req.body.type : 'hat';
  const liveAt = Date.now() + Math.max(0, +req.body.live_at || 0) * 6e4;
  const stockN = (stock === '' || stock == null || !Number.isFinite(+stock)) ? -1 : Math.trunc(+stock);
  q('INSERT INTO items(name,price,type,img,stock,roblox_id,live_at,hidden,created) VALUES(?,?,?,?,?,?,?,0,?)')
    .run(name, Math.max(0, Math.trunc(+price || 0)), type, img, stockN, rid || null, liveAt, Date.now());
  res.json({ ok: 1, name });
});
app.post('/api/admin/item/hide', A, (req, res) => {
  q('UPDATE items SET hidden=CASE WHEN hidden=1 THEN 0 ELSE 1 END WHERE id=?').run(Number(req.body.id));
  res.json({ ok: 1 });
});
app.get('/api/admin/promos', A, (req, res) => res.json(q('SELECT p.*,i.name item_name FROM promos p LEFT JOIN items i ON i.id=p.item_id ORDER BY p.created DESC').all()));
app.post('/api/admin/promo', A, (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const robux = Math.max(0, Math.trunc(+req.body.robux || 0));
  const item = req.body.item_id ? Number(req.body.item_id) : null;
  const uses = (req.body.uses === '' || req.body.uses == null || !Number.isFinite(+req.body.uses)) ? -1 : Math.trunc(+req.body.uses);
  if (!/^[A-Z0-9_-]{3,24}$/.test(code)) return res.status(400).json({ error: 'Codes are 3-24 letters, numbers, - or _' });
  if (!robux && !item) return res.status(400).json({ error: 'Give the code Robux, an item ID, or both' });
  if (item && !q('SELECT 1 FROM items WHERE id=?').get(item)) return res.status(400).json({ error: 'No item has that ID' });
  q('INSERT OR REPLACE INTO promos(code,robux,item_id,uses,active,created) VALUES(?,?,?,?,1,?)').run(code, robux, item, uses, Date.now());
  res.json({ ok: 1 });
});
app.post('/api/admin/promo/toggle', A, (req, res) => {
  q('UPDATE promos SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE code=?').run(String(req.body.code || '').toUpperCase());
  res.json({ ok: 1 });
});
app.post('/api/admin/promo/delete', A, (req, res) => {
  q('DELETE FROM promos WHERE code=?').run(String(req.body.code || '').toUpperCase());
  res.json({ ok: 1 });
});
app.post('/api/admin/ban', A, (req, res) => {
  const u = byName(req.body.name);
  if (!u) return res.status(404).json({ error: 'No such user' });
  if (u.id === req.u.id) return res.status(400).json({ error: 'You cannot ban yourself' });
  q('UPDATE users SET banned=? WHERE id=?').run(req.body.unban ? 0 : 1, u.id);
  if (!req.body.unban) q('DELETE FROM sessions WHERE uid=?').run(u.id);
  res.json({ ok: 1 });
});
app.post('/api/admin/robux', A, (req, res) => {
  const amt = Math.trunc(+req.body.amount);
  if (!amt || Math.abs(amt) > 1e7) return res.status(400).json({ error: 'Enter a whole number (negative takes Robux away)' });
  const u = byName(req.body.name);
  if (!u) return res.status(404).json({ error: 'No such user' });
  const nb = Math.max(0, u.robux + amt);
  q('UPDATE users SET robux=? WHERE id=?').run(nb, u.id);
  log(u.id, nb - u.robux, 'admin: ' + req.u.name);
  res.json({ ok: 1, balance: nb });
});
app.get('/api/admin/robuxlog', A, (req, res) => res.json(q('SELECT l.*,u.name FROM robux_log l JOIN users u ON u.id=l.uid ORDER BY l.id DESC LIMIT 25').all()));
app.post('/api/admin/badge', A, (req, res) => {
  const u = byName(req.body.name), b = String(req.body.badge || '');
  if (!u) return res.status(404).json({ error: 'No such user' });
  if (!BADGES.includes(b)) return res.status(400).json({ error: 'Unknown badge' });
  q('INSERT OR IGNORE INTO badges(uid,badge) VALUES(?,?)').run(u.id, b);
  res.json({ ok: 1 });
});
app.post('/api/admin/badge/remove', A, (req, res) => {
  const u = byName(req.body.name), b = String(req.body.badge || '');
  if (!u) return res.status(404).json({ error: 'No such user' });
  q('DELETE FROM badges WHERE uid=? AND badge=?').run(u.id, b);
  res.json({ ok: 1 });
});
app.post('/api/admin/blog', A, (req, res) => {
  const t = String(req.body.title || '').trim().slice(0, 120);
  if (!t) return res.status(400).json({ error: 'Enter a title' });
  q('INSERT INTO blog(title,author,ts) VALUES(?,?,?)').run(t, req.u.name, Date.now());
  res.json({ ok: 1 });
});
app.post('/api/admin/event', A, (req, res) => {
  const t = String(req.body.title || '').trim().slice(0, 120);
  if (!t) return res.status(400).json({ error: 'Enter a title' });
  q('INSERT INTO events(title,img) VALUES(?,?)').run(t, String(req.body.img || ''));
  res.json({ ok: 1 });
});
app.post('/api/admin/game', A, (req, res) => {
  const n = String(req.body.name || '').trim().slice(0, 60);
  if (!n) return res.status(400).json({ error: 'Enter a game name' });
  q('INSERT INTO games(name,img,creator,updated) VALUES(?,?,?,?)').run(n, String(req.body.img || ''), req.u.name, Date.now());
  res.json({ ok: 1 });
});

// owner-only: used by admin_whitelister.py
app.post('/api/owner/whitelist', (req, res) => {
  if (!keyOk(req.get('x-owner-key'))) return res.status(403).json({ error: 'Bad owner key' });
  const u = byName(req.body.name);
  if (!u) return res.json({ ok: 0 });
  if (req.body.remove) q('UPDATE users SET admin=0 WHERE id=?').run(u.id);
  else { q('UPDATE users SET admin=1 WHERE id=?').run(u.id); q('INSERT OR IGNORE INTO badges(uid,badge) VALUES(?,?)').run(u.id, 'staff'); }
  res.json({ ok: 1 });
});

app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.status && err.status < 500 ? err.message : 'Something went wrong on the server. Check the terminal.' });
});

if (require.main === module) {
  app.listen(process.env.PORT || 3000, () => console.log(`Exthren running on :${process.env.PORT || 3000}`));
}
module.exports = { app };
