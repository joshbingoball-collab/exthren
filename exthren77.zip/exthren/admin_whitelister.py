# Exthren Admin Whitelister. Build exe: pip install pyinstaller && pyinstaller --onefile --noconsole --name "Exthren Admin Whitelister" admin_whitelister.py
import tkinter as tk, json, urllib.request
SERVER="http://localhost:3000"; KEY="change-me-owner-key"   # set to your domain + OWNER_KEY
def send(remove):
    req=urllib.request.Request(SERVER+"/api/owner/whitelist",json.dumps({"name":e.get().strip(),"remove":remove}).encode(),{"Content-Type":"application/json","x-owner-key":KEY})
    try: out=json.load(urllib.request.urlopen(req)); s="Done" if out.get("ok") else "User not found"
    except Exception as x: s="Error: "+str(x)
    lbl.config(text=s)
w=tk.Tk(); w.title("Exthren Admin Whitelister"); w.geometry("320x140")
tk.Label(w,text="Username").pack(pady=4); e=tk.Entry(w,width=30); e.pack()
f=tk.Frame(w); f.pack(pady=6); tk.Button(f,text="Grant Admin",command=lambda:send(False)).pack(side="left",padx=4); tk.Button(f,text="Revoke",command=lambda:send(True)).pack(side="left")
lbl=tk.Label(w,text=""); lbl.pack(); w.mainloop()
